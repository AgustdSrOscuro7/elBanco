package co.edu.usbcali.elBanco.dtos;
import lombok.Builder;
import lombok.Data;
@Builder
@Data
public class MensajeDTO {
    private String mensajes;
}
