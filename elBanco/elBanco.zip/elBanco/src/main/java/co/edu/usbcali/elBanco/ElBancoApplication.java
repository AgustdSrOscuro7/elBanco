package co.edu.usbcali.elBanco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class  ElBancoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElBancoApplication.class, args);
	}

}
